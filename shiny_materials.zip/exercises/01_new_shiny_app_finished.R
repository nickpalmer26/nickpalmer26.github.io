
## Exercise 1: Create a new shiny app.

## 1. Start typing `shinyapp` and select the shinyapp *snippet*.

## 2. Save the file and click the "Run App" button. You should see a blank app and no errors!

## 3. Add some text inside the ui element, e.g., "Hello World!". Save and click the "Reload App" button".

library(shiny)

ui <- fluidPage(
  "Hello world!"
)

server <- function(input, output, session) {
  
}

shinyApp(ui, server)